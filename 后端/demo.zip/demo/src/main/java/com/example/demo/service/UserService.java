package com.example.demo.service;

import com.example.demo.entity.User;
import com.example.demo.entity.bz;
import org.apache.ibatis.annotations.Insert;

import java.util.List;

public interface UserService {


    User select(String username);

    void insert(String username, String md5String);

    User selectid(String username);


}
