package com.example.demo.controller;

import com.example.demo.common.config.websocket.WebSocketHandler;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/ws")
public class WebSocketController {

    private final WebSocketHandler webSocketHandler;

    public WebSocketController(WebSocketHandler webSocketHandler) {
        this.webSocketHandler = webSocketHandler;
    }
    @GetMapping("/random-id/{userId}")
    public Optional<String> getRandomAvailableUserId(@PathVariable String userId) {
        return webSocketHandler.getRandomAvailableUserId(userId);
    }
    @PostMapping("/send/{userId}")
    public void sendMessage(@PathVariable String userId, @RequestParam String targetUserId, @RequestParam String message) {
        try {
            webSocketHandler.sendMessageToUser(targetUserId, message);
            System.out.println("用户ID: " + userId + " 发送消息到用户ID: " + targetUserId + " 内容: " + message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // 修改后的 GET 请求接口，用于解除用户 ID 的禁止状态
    @GetMapping("/enable/{userId}")
    public void enableUserId(@PathVariable String userId) {
        try {
            webSocketHandler.enableUserId(userId);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
