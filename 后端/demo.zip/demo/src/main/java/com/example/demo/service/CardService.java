package com.example.demo.service;

import com.example.demo.entity.bz;

import java.util.List;

public interface CardService {
    //根据id查卡牌
    List<bz> selectkp(String id);

    void insertkp(String id,String kzmc,String kpmc,String kpsx,String kpjn);

    public void updarekp(String id, String kzmc, String kpmc, String kpsx, String kpjn,String kpmcx);

    public void updarekb(String id, String kzmc, String kzmcx);

    void insertkzcj(String id,String kzmc);
}
