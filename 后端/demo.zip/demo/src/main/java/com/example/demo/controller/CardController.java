package com.example.demo.controller;

import com.example.demo.entity.Result;
import com.example.demo.entity.bz;
import com.example.demo.service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/card")
public class CardController {
    @Autowired
    private CardService cardService;
    //卡牌查询
    @GetMapping("kpcx")
    public List<bz> selectkp(String id){
        return cardService.selectkp(id);//根据id查询卡牌
    }
    //插入卡牌
    @GetMapping("kpcr")
    public Result insertkp(String id, String kzmc, String kpmc, String kpsx, String kpjn){
       cardService.insertkp(id,kzmc,kpmc,kpsx,kpjn);
        return Result.success();
    }

    @GetMapping("kpbc")
    public Result updarekp(String id, String kzmc, String kpmc, String kpsx, String kpjn,String kpmcx){
        cardService.updarekp(id,kzmc,kpmc,kpsx,kpjn,kpmcx);
        return Result.success();
    }

    @GetMapping("kzcj")
    public Result insertkzcj(String id, String kzmc){
        cardService.insertkzcj(id,kzmc);
        return Result.success();
    }
    @GetMapping("kzxg")
    public Result updarekb(String id, String kzmc,String kzmcx){
        cardService.updarekb(id,kzmc,kzmcx);
        return Result.success();
    }
}
