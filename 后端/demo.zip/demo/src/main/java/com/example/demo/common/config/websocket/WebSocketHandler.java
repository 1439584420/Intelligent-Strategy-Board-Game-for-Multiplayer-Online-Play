package com.example.demo.common.config.websocket;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class WebSocketHandler extends TextWebSocketHandler {

    private final ConcurrentHashMap<String, WebSocketSession> sessions = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Boolean> usedIds = new ConcurrentHashMap<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        try {
            String userId = extractUserId(session);
            sessions.put(userId, session);
            usedIds.put(userId, false);  // 默认不禁止
            System.out.println("用户ID:" + userId + "链接成功");
        } catch (Exception e) {
            System.out.println("链接失败:" + session.getId());
            throw e;
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        String userId = extractUserId(session);
        sessions.remove(userId);
        usedIds.remove(userId);
        System.out.println("用户ID:" + userId + "链接已关闭");
    }

    public Optional<String> getRandomAvailableUserId(String requestUserId) {
        List<String> availableIds = new ArrayList<>(sessions.keySet());
        availableIds.removeAll(usedIds.keySet());  // 确保删除所有禁止的ID
        availableIds.remove(requestUserId);  // 确保请求者自己的ID不在可选列表中

        if (availableIds.isEmpty()) {
            return Optional.empty();  // 没有可用的ID
        }

        String randomId = availableIds.get(new Random().nextInt(availableIds.size()));
        usedIds.put(randomId, true);
        usedIds.put(requestUserId, true);  // 禁止请求者ID再次被获取

        // 发送当前用户的ID给随机选中的用户
        CompletableFuture<Boolean> result = sendMessageToUser(randomId,  "匹配成功:"+requestUserId);
        result.thenAccept(success -> {
            if (success) {
                System.out.println("当前用户ID:" + requestUserId + " 成功发送给用户ID:" + randomId);
            } else {
                System.out.println("当前用户ID:" + requestUserId + " 发送失败给用户ID:" + randomId);
            }
        });

        return Optional.of(randomId);
    }

    public CompletableFuture<Boolean> sendMessageToUser(String userId, String message) {
        WebSocketSession session = sessions.get(userId);
        if (session != null && session.isOpen()) {
            return CompletableFuture.supplyAsync(() -> {
                try {
                    session.sendMessage(new TextMessage(message));
                    System.out.println("消息已发送至用户ID:" + userId);
                    return true;
                } catch (Exception e) {
                    System.out.println("发送失败，用户ID:" + userId + " 可能未连接或已断开");
                    e.printStackTrace();
                    return false;
                }
            });
        } else {
            System.out.println("发送失败，用户ID:" + userId + " 可能未连接或已断开");
            return CompletableFuture.completedFuture(false);
        }
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        String payload = message.getPayload();
        String userId = extractUserId(session);
        System.out.println("收到消息:" + payload + " 来自用户ID:" + userId);

        // 解析消息 payload
        String[] parts = payload.split(" ", 2);  // 假设消息格式为 "userId message"
        if (parts.length == 2) {
            String targetUserId = parts[0];
            String msg = parts[1];
            CompletableFuture<Boolean> result = sendMessageToUser(targetUserId, msg);
            result.thenAccept(success -> {
                if (success) {
                    System.out.println("消息成功发送给用户ID:" + targetUserId);
                } else {
                    System.out.println("消息发送失败给用户ID:" + targetUserId);
                    sendMessageToUser(userId, "消息发送失败");
                }
            });
        } else {
            System.out.println("消息格式错误:" + payload);
        }
    }

    private String extractUserId(WebSocketSession session) {
        return session.getUri().getQuery().split("=")[1];
    }

    // 使禁止状态失效的方法
    public void enableUserId(String userId) {
        usedIds.remove(userId);
        System.out.println("用户ID:" + userId + " 禁止状态已失效");
    }
}