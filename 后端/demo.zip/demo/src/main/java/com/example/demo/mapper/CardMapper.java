package com.example.demo.mapper;

import com.example.demo.entity.bz;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface CardMapper {
    @Select("select id,kzmc,kpmc,kpsx,kpjn,kpxh from bz where id=#{id}")
    List<bz> selectkp(String id);
    @Insert("insert into bz(id,kzmc,kpmc,kpsx,kpjn) values(#{id},#{kzmc},#{kpmc},#{kpsx},#{kpjn})")
    void insertkp(String id, String kzmc, String kpmc, String kpsx, String kpjn);

    @Update("UPDATE bz set kpsx= #{kpsx}, kpjn = #{kpjn},kpmc = #{kpmcx} WHERE id = #{id} AND kzmc = #{kzmc} AND kpmc = #{kpmc}")
    void updarekp(String id, String kzmc, String kpmc, String kpsx, String kpjn,String kpmcx);

    @Insert("insert into bz(id,kzmc) values(#{id},#{kzmc})")
    void insertkzcj(String id, String kzmc);

    @Update("UPDATE bz set kzmc = #{kzmcx} WHERE id = #{id} AND kzmc = #{kzmc} ")
    void updarekb(String id, String kzmc, String kzmcx);
}
