package com.example.demo.service.Impl;

import com.example.demo.entity.bz;
import com.example.demo.mapper.CardMapper;
import com.example.demo.service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CardServiceImpl implements CardService {
    @Autowired
    private CardMapper cardMapper;
    @Override
    public List<bz> selectkp(String id) {
        return cardMapper.selectkp(id);
    }

    @Override
    public void insertkp(String id, String kzmc, String kpmc, String kpsx, String kpjn) {
        cardMapper.insertkp(id,kzmc,kpmc,kpsx,kpjn);
    }
    @Override
    public void updarekp(String id, String kzmc, String kpmc, String kpsx, String kpjn,String kpmcx) {
        cardMapper.updarekp(id,kzmc,kpmc,kpsx,kpjn,kpmcx);
    }

    @Override
    public void updarekb(String id, String kzmc, String kzmcx) {
        cardMapper.updarekb(id,kzmc,kzmcx);
    }

    @Override
    public void insertkzcj(String id, String kzmc) {
        cardMapper.insertkzcj(id,kzmc);
    }

}
