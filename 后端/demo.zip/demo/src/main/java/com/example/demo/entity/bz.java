package com.example.demo.entity;

import lombok.Data;

@Data
public class bz {

    private int id;
    private String kzmc;
    private String kpmc;
    private String kpsx;
    private String kpjn;
    private int kpxh;
}
