package com.example.demo.controller;

import com.example.demo.entity.Result;
import com.example.demo.entity.User;
import com.example.demo.entity.bz;
import com.example.demo.mapper.Usermapper;
import com.example.demo.service.UserService;
import com.example.demo.utils.Md5Util;
import jakarta.annotation.Nullable;
import jakarta.annotation.Resource;
import org.apache.ibatis.jdbc.Null;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class Usercontroller {
    @Autowired
    private UserService userService;
    //查询所有用户

    //根据账号查询用户 若有则注册
    @GetMapping("register")
    public Result select(String username,String password){
        User u = userService.select(username); //根据账号查询密码
        if(u==null){

            String md5String = Md5Util.getMD5String(password);

            userService.insert(username,md5String);
            return Result.success(userService.selectid(username));
        }
        return  Result.error("账号已存在");

    }
    //登录
    @GetMapping("login")
    public Result login(String username,String password){
        User u = userService.select(username); //根据账号查询密码
        if(u==null){
            return Result.error("账号不存在");
        }
        String password1 = u.getPassword();

        if(Md5Util.getMD5String(password).equals(password1)){
            return Result.success(userService.selectid(username));//返回id
        }

        return Result.error("密码错误");

    }










//    //插入user
//    @PostMapping("insert")
//    public Result insert(String username,String password){
//        userService.insert(username,password);
//        return  Result.success();
//    }

}
