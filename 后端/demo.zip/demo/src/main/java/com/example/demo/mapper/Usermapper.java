package com.example.demo.mapper;

import com.example.demo.entity.User;
import com.example.demo.entity.bz;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface Usermapper {

    @Select("select password from user where username=#{username}")
    User select(String username);
    //插入用户
    @Insert("insert into user(username,password) values(#{username},#{password})")
    void insert(String username,String password);


    @Select("select id from user where username=#{username}")
    User selectid(String username);


}
